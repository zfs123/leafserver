Leaf server
===========
A game server based on [Leaf framework](https://github.com/name5566/leaf).

Licensing
---------

Leaf server is licensed under the Apache License, Version 2.0. See [LICENSE](https://github.com/name5566/leafserver/blob/master/LICENSE) for the full license text.
