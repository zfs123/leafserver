﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Util;

class ChatManager : Singleton<ChatManager>, IManager
{
    public void Init()
    {
    }
}
