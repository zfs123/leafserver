package gamedata
func LoadTables()  {
    TestTableinit()
}