from TableCode.excel import excel_start

excel_start()

print("finished...")