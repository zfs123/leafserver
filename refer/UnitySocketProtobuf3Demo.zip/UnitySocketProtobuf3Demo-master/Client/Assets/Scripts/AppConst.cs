﻿using UnityEngine;
using System.Collections;

public class AppConst {
    public static int SocketPort = 3563;                           //Socket服务器端口
    public static string SocketAddress = "127.0.0.1";          //Socket服务器地址
}
