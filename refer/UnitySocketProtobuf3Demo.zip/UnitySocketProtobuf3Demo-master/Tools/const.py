

proto_path = "Proto/src"
csfile_path = "../Client/Assets/Scripts/Net/ProtoDic.cs"
gofile_path = "../Server/src/server/msg/msg.go"

#########################################################
### table
#########################################################


excel_dir = "TableData"
cs_table_data_dir = "../Client/Assets/GameData/TableData/"
cs_table_file_dir = "../Client/Assets/Scripts/Tables/"
go_table_data_dir = "../Server/bin/gamedata/"
go_table_file_dir = "../Server/src/server/gamedata/"

