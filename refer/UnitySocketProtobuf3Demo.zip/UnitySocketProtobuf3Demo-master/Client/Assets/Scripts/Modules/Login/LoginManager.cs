﻿using UnityEngine;
using System.Collections;
using Util;

public class LoginManager : Singleton<LoginManager>, IManager
{
    public void Init()
    {
    }
}
