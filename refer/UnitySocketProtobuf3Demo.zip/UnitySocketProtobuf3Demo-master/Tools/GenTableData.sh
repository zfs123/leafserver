#!/usr/bin/env bash
python3 gen_table_data.py
pause